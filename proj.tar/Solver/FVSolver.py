import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from tqdm import tqdm

class FVSolver3D:
    def __init__(self, mesh, materials_dict):
        """
        mesh: l'oggetto Mesh3D
        materials_dict: un dizionario che mappa gli ID (0, 1, 2) agli oggetti Material
        """
        self.mesh = mesh
        self.materials_dict = materials_dict
        
        # Dimensioni della matrice
        self.N_nodes = mesh.N_x * mesh.N_y * mesh.N_z
        
        # Passi spaziali
        self.dx = mesh.x[1] - mesh.x[0]
        self.dy = mesh.y[1] - mesh.y[0]
        self.dz = mesh.z[1] - mesh.z[0]

    def _build_sigma_map(self, f):
        """Mappa gli ID interi dei materiali nella Conduttività Complessa (Sigma)"""
        Sigma = np.zeros_like(self.mesh.material_map, dtype=complex)
        for mat_id, material in self.materials_dict.items():
            mask = (self.mesh.material_map == mat_id)
            Sigma[mask] = material.get_complex_conductivity(f)
        return Sigma

    def _harmonic_mean(self, S1, S2):
        """Calcola la media armonica tra due array complessi."""
        # Aggiungiamo un epsilon piccolissimo per evitare divisioni per zero
        eps = 1e-15
        return (2 * S1 * S2) / (S1 + S2 + eps)

    def assemble_and_solve(self, f, boundaries_manager):
        print(f"--- Inizio Soluzione per f = {f} Hz ---")
        
        # 1. Mappa della conduttività
        Sigma = self._build_sigma_map(f)
        
        # 2. Calcolo Flussi
        print("  -> Calcolo delle conduttanze di interfaccia...")
        S_xp = np.roll(Sigma, -1, axis=0); G_xp = self._harmonic_mean(Sigma, S_xp) * (self.dy * self.dz / self.dx)
        S_xm = np.roll(Sigma, 1, axis=0);  G_xm = self._harmonic_mean(Sigma, S_xm) * (self.dy * self.dz / self.dx)
        
        S_yp = np.roll(Sigma, -1, axis=1); G_yp = self._harmonic_mean(Sigma, S_yp) * (self.dx * self.dz / self.dy)
        S_ym = np.roll(Sigma, 1, axis=1);  G_ym = self._harmonic_mean(Sigma, S_ym) * (self.dx * self.dz / self.dy)
        
        S_zp = np.roll(Sigma, -1, axis=2); G_zp = self._harmonic_mean(Sigma, S_zp) * (self.dx * self.dy / self.dz)
        S_zm = np.roll(Sigma, 1, axis=2);  G_zm = self._harmonic_mean(Sigma, S_zm) * (self.dx * self.dy / self.dz)
        
        G_center = (G_xp + G_xm + G_yp + G_ym + G_zp + G_zm)
        
        # 3. Assemblaggio Matrice
        print("  -> Assemblaggio matrice sparsa...")
        node_indices = np.arange(self.N_nodes)
        
        idx_xp = np.roll(node_indices.reshape(self.mesh.N_x, self.mesh.N_y, self.mesh.N_z), -1, axis=0).flatten()
        idx_xm = np.roll(node_indices.reshape(self.mesh.N_x, self.mesh.N_y, self.mesh.N_z), 1, axis=0).flatten()
        idx_yp = np.roll(node_indices.reshape(self.mesh.N_x, self.mesh.N_y, self.mesh.N_z), -1, axis=1).flatten()
        idx_ym = np.roll(node_indices.reshape(self.mesh.N_x, self.mesh.N_y, self.mesh.N_z), 1, axis=1).flatten()
        idx_zp = np.roll(node_indices.reshape(self.mesh.N_x, self.mesh.N_y, self.mesh.N_z), -1, axis=2).flatten()
        idx_zm = np.roll(node_indices.reshape(self.mesh.N_x, self.mesh.N_y, self.mesh.N_z), 1, axis=2).flatten()

        rows = np.concatenate([node_indices, node_indices, node_indices, node_indices, node_indices, node_indices, node_indices])
        cols = np.concatenate([node_indices, idx_xp, idx_xm, idx_yp, idx_ym, idx_zp, idx_zm])
        data = np.concatenate([G_center.flatten(), -G_xp.flatten(), -G_xm.flatten(), 
                               -G_yp.flatten(), -G_ym.flatten(), -G_zp.flatten(), -G_zm.flatten()])
        
        A = sp.coo_matrix((data, (rows, cols)), shape=(self.N_nodes, self.N_nodes), dtype=complex)
        A_lil = A.tolil()
        b = np.zeros(self.N_nodes, dtype=complex)
        
        # 4. Applicazione Boundary Conditions
        print("  -> Applicazione Boundary Conditions...")
        boundaries_manager.apply_all(A_lil, b)
        reg = sp.eye(self.N_nodes, format='lil') * 1e-12
        A_lil = A_lil + reg

        # ==========================================================
        # 5. RISOLUZIONE ITERATIVA CON PROGRESS BAR REALE
        # ==========================================================
        print("  -> Risoluzione del sistema (BiCGSTAB)...")
        A_csr = A_lil.tocsr()
        
        # Usiamo il solutore diretto: infallibile ma richiede pazienza e RAM
        phi_1d = spla.spsolve(A_csr, b)

        # 6. Ritorno alla forma 3D
        phi_3d = phi_1d.reshape((self.mesh.N_x, self.mesh.N_y, self.mesh.N_z))
        
        return phi_3d