import numpy as np

# Importiamo i moduli
from Geometry.Mesh3D import Mesh3D
from Geometry.SystemGeometry import SystemGeometry
from Boundaries.SystemBoundaries import SystemBoundaries3D
from Materials.Materials import Material
from Solver.FVSolver import FVSolver3D
from GUI.plot_slice import plot_slice_yz

def main():
    print("Inizializzazione del sistema...")
    
    # 1. Setup dei parametri geometrici
    X_max, Y_max, Z_max = 203.0, 203.0, 400.0
    N_x, N_y, N_z = 81, 81, 100 
    h1_val, h_val = 100.0, 230.0
    a_e = 70.0  # Raggio elettrodo
    V_0 = 1.0   # Potenziale all'elettrodo in Volt
    f_sim = 1000.0 # Frequenza di simulazione in Hz
    
    # 2. Creazione della Mesh e Geometria
    print("Generazione Mesh e Geometria...")
    mesh = Mesh3D(X_max, Y_max, Z_max, N_x, N_y, N_z)
    sys_geo = SystemGeometry(mesh)
    sys_geo.build_system(
        h1=h1_val, h=h_val, 
        r_aperture_bottom=5.0, r_aperture_top=200.0,
        cell_r=0.0 # Nessuna cellula
    )
    
    # 3. Definizione dei Materiali
    print("Assegnazione Proprietà Fisiche...")
    # Usiamo valori tipici: Idrogelo leggermente meno conduttivo dell'Elettrolita
    materials_dict = {
        0: Material("Hydrogel", sigma=0.1, epsilon_r=80),
        1: Material("Electrolyte", sigma=1.5, epsilon_r=80)
    }
    
    # 4. Creazione delle Condizioni al Contorno
    print("Inizializzazione Condizioni al Contorno...")
    sys_bounds = SystemBoundaries3D(mesh, a_e, V_0)
    
    # =========================================================
    # 5. ESECUZIONE DEL SOLUTORE FVM
    # =========================================================
    print(f"Inizializzazione Solutore per f = {f_sim} Hz...")
    solver = FVSolver3D(mesh, materials_dict)
    
    # Calcoliamo la vera distribuzione del potenziale complesso phi
    phi_complex = solver.assemble_and_solve(f=f_sim, boundaries_manager=sys_bounds)
    
    # Estraiamo l'ampiezza (modulo) del potenziale per la visualizzazione
    phi_amplitude = np.abs(phi_complex)
    
    # =========================================================
    # 6. VISUALIZZAZIONE DEI RISULTATI
    # =========================================================
    print("Apertura del grafico 2D con la soluzione reale...")
    plot_slice_yz(mesh, phi_amplitude, a_e)

if __name__ == "__main__":
    main()